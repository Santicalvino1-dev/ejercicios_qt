#include "formulario.h"
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

Formulario::Formulario(QWidget *parent) : QWidget(parent) {
    setWindowTitle("Formulario");

    QLabel *labelLegajo = new QLabel("Legajo:");
    QLabel *labelNombre = new QLabel("Nombre:");
    QLabel *labelApellido = new QLabel("Apellido:");

    QLineEdit *editLegajo = new QLineEdit;
    QLineEdit *editNombre = new QLineEdit;
    QLineEdit *editApellido = new QLineEdit;
    QPushButton *boton = new QPushButton("Enviar");

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(labelLegajo, 0, 0);
    layout->addWidget(editLegajo, 0, 1);
    layout->addWidget(labelNombre, 1, 0);
    layout->addWidget(editNombre, 1, 1);
    layout->addWidget(labelApellido, 2, 0);
    layout->addWidget(editApellido, 2, 1);
    layout->addWidget(boton, 3, 1);

    setLayout(layout);
}