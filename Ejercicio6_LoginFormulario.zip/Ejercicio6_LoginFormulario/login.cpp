#include "login.h"
#include "formulario.h"
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QKeyEvent>

Login::Login(QWidget *parent) : QWidget(parent) {
    setWindowTitle("Login");
    resize(300, 150);

    QLabel *labelLegajo = new QLabel("Legajo:");
    QLabel *labelClave = new QLabel("Clave:");
    legajo = new QLineEdit;
    clave = new QLineEdit;
    clave->setEchoMode(QLineEdit::Password);
    boton = new QPushButton("Ingresar");

    QGridLayout *layout = new QGridLayout;
    layout->addWidget(labelLegajo, 0, 0);
    layout->addWidget(legajo, 0, 1);
    layout->addWidget(labelClave, 1, 0);
    layout->addWidget(clave, 1, 1);
    layout->addWidget(boton, 2, 1);

    setLayout(layout);

    connect(boton, SIGNAL(clicked()), this, SLOT(verificar()));
    connect(clave, SIGNAL(returnPressed()), boton, SLOT(click()));
}

void Login::verificar() {
    if (clave->text() == "1111" && legajo->text().toLower() == "admin") {
        Formulario *form = new Formulario;
        form->show();
        close();
    } else {
        clave->clear();
    }
}