#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>

class QLineEdit;
class QPushButton;

class Login : public QWidget {
    Q_OBJECT

public:
    Login(QWidget *parent = nullptr);

private slots:
    void verificar();

private:
    QLineEdit *legajo;
    QLineEdit *clave;
    QPushButton *boton;
};

#endif // LOGIN_H