#include <QCoreApplication>
#include <QElapsedTimer>
#include <QDebug>
#include <cstdlib>
#include <ctime>

class Sensor {
public:
    Sensor() {
        valorActual = rand() % 1024;
    }

    int getValorBruto() const { return valorActual; }

    int getValorBrutoOffline() const;

    inline double getValorNormalizado() const {
        return valorActual / 1023.0;
    }

    double getValorNormalizadoOffline() const;

private:
    int valorActual;
};

int Sensor::getValorBrutoOffline() const {
    return valorActual;
}

double Sensor::getValorNormalizadoOffline() const {
    return valorActual / 1023.0;
}

int main(int argc, char *argv[]) {
    QCoreApplication a(argc, argv);
    srand(static_cast<unsigned>(time(nullptr)));

    Sensor sensor;

    QElapsedTimer timer;

    timer.start();
    for (int i = 0; i < 10000000; ++i)
        sensor.getValorBruto();
    qDebug() << "Tiempo getValorBruto (inline implícito):" << timer.elapsed() << "ms";

    timer.restart();
    for (int i = 0; i < 10000000; ++i)
        sensor.getValorBrutoOffline();
    qDebug() << "Tiempo getValorBrutoOffline (offline):" << timer.elapsed() << "ms";

    timer.restart();
    for (int i = 0; i < 10000000; ++i)
        sensor.getValorNormalizado();
    qDebug() << "Tiempo getValorNormalizado (inline explícito):" << timer.elapsed() << "ms";

    timer.restart();
    for (int i = 0; i < 10000000; ++i)
        sensor.getValorNormalizadoOffline();
    qDebug() << "Tiempo getValorNormalizadoOffline (offline):" << timer.elapsed() << "ms";

    return 0;
}