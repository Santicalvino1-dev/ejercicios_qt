#include "ventana.h"
#include <QVBoxLayout>
#include <QLabel>
#include <QPixmap>
#include <QNetworkRequest>

Ventana::Ventana(QWidget *parent) : QWidget(parent) {
    imagenFondo = new QLabel;
    imagenFondo->setAlignment(Qt::AlignCenter);

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->addWidget(imagenFondo);

    manager = new QNetworkAccessManager(this);
    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(imagenCargada(QNetworkReply*)));

    QUrl url("https://picsum.photos/1920/1080"); // imagen ventana
    manager->get(QNetworkRequest(url));
}

void Ventana::imagenCargada(QNetworkReply *reply) {
    QPixmap pix;
    pix.loadFromData(reply->readAll());

    QSize pantalla = size();
    imagenFondo->setPixmap(pix.scaled(pantalla, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    reply->deleteLater();
}