#include "login.h"
#include "ui_login.h"
#include "ventana.h"
#include <QNetworkRequest>
#include <QMessageBox>
#include <QPixmap>
#include <QPalette>
#include <QBrush>

Login::Login(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Login)
{
    ui->setupUi(this);

    manager = new QNetworkAccessManager(this);
    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(fondoDescargado(QNetworkReply*)));

    QUrl url("https://picsum.photos/800/600"); // fondo login
    manager->get(QNetworkRequest(url));
}

Login::~Login() {
    delete ui;
}

void Login::fondoDescargado(QNetworkReply *reply) {
    QPixmap pix;
    pix.loadFromData(reply->readAll());

    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(pix.scaled(size(), Qt::KeepAspectRatioByExpanding, Qt::SmoothTransformation)));
    setPalette(palette);
    setAutoFillBackground(true);

    reply->deleteLater();
}

void Login::on_botonLogin_clicked() {
    QString usuario = ui->usuario->text();
    QString clave = ui->clave->text();

    if (usuario == "admin" && clave == "1234") {
        Ventana *v = new Ventana;
        v->showFullScreen();
        close();
    } else {
        QMessageBox::warning(this, "Error", "Credenciales inválidas");
        ui->clave->clear();
    }
}