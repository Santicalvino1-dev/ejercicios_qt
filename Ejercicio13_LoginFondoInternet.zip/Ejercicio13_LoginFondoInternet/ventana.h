#ifndef VENTANA_H
#define VENTANA_H

#include <QWidget>
#include <QNetworkAccessManager>
#include <QNetworkReply>

class QLabel;

class Ventana : public QWidget {
    Q_OBJECT

public:
    Ventana(QWidget *parent = nullptr);

private slots:
    void imagenCargada(QNetworkReply *reply);

private:
    QLabel *imagenFondo;
    QNetworkAccessManager *manager;
};

#endif // VENTANA_H