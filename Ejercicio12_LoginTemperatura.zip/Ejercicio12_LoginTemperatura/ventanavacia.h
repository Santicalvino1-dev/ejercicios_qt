#ifndef VENTANAVACIA_H
#define VENTANAVACIA_H

#include <QWidget>

class VentanaVacia : public QWidget {
    Q_OBJECT

public:
    VentanaVacia(QWidget *parent = nullptr);
};

#endif // VENTANAVACIA_H