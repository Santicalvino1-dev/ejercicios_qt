#include "ventanavacia.h"

VentanaVacia::VentanaVacia(QWidget *parent) : QWidget(parent) {
    setWindowTitle("Ventana Nueva");
    resize(400, 300);
}