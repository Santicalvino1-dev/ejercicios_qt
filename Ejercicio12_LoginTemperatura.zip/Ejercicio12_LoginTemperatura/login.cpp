#include "login.h"
#include "ui_login.h"
#include "ventanavacia.h"
#include <QMessageBox>
#include <QJsonDocument>
#include <QJsonObject>

Login::Login(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Login)
{
    ui->setupUi(this);

    manager = new QNetworkAccessManager(this);
    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(procesarRespuesta(QNetworkReply*)));

    // Llamar a la API del clima (Open-Meteo, sin key)
    QUrl url("https://api.open-meteo.com/v1/forecast?latitude=-31.4167&longitude=-64.1833&current_weather=true");
    manager->get(QNetworkRequest(url));
}

Login::~Login() {
    delete ui;
}

void Login::on_botonLogin_clicked() {
    QString usuario = ui->usuario->text();
    QString clave = ui->clave->text();

    if (usuario == "admin" && clave == "1234") {
        this->close();
        VentanaVacia *ventana = new VentanaVacia;
        ventana->show();
    } else {
        QMessageBox::warning(this, "Error", "Credenciales inválidas");
        ui->clave->clear();
    }
}

void Login::procesarRespuesta(QNetworkReply *reply) {
    QByteArray respuesta = reply->readAll();
    QJsonDocument json = QJsonDocument::fromJson(respuesta);
    if (json.isObject()) {
        QJsonObject obj = json.object();
        QJsonObject clima = obj["current_weather"].toObject();
        double temp = clima["temperature"].toDouble();
        ui->temperatura->setText("Temperatura Córdoba: " + QString::number(temp) + "°C");
    }
    reply->deleteLater();
}