#include <QCoreApplication>
#include <iostream>
#include <vector>
#include <memory>

using namespace std;

class Instrumento {
public:
    virtual void sonar() const = 0;
    virtual void verlo() const {
        cout << "Marca: Yamaha" << endl;
    }
    virtual ~Instrumento() {}
};

class Guitarra : public Instrumento {
    int cuerdas;
public:
    Guitarra(int c = 6) : cuerdas(c) {}
    void sonar() const override {
        cout << "Guitarra suena..." << endl;
    }
    void verlo() const override {
        cout << "Guitarra - Marca: Yamaha, Cuerdas: " << cuerdas << endl;
    }
};

class Bateria : public Instrumento {
    int tambores;
public:
    Bateria(int t = 5) : tambores(t) {}
    void sonar() const override {
        cout << "Batería suena..." << endl;
    }
    void verlo() const override {
        cout << "Batería - Marca: Yamaha, Tambores: " << tambores << endl;
    }
};

class Electrico {
    int voltaje;
public:
    Electrico(int v = 220) : voltaje(v) {}
    int getVoltaje() const { return voltaje; }
    virtual ~Electrico() {
        cout << "Desenchufado" << endl;
    }
};

class Teclado : public Instrumento, public Electrico {
    int teclas;
public:
    Teclado(int t = 61) : teclas(t) {}
    void sonar() const override {
        cout << "Teclado suena..." << endl;
    }
    void verlo() const override {
        cout << "Teclado - Marca: Yamaha, Teclas: " << teclas << ", Voltaje: " << getVoltaje() << endl;
    }
};

int main(int argc, char *argv[]) {
    QCoreApplication a(argc, argv);

    vector<Instrumento*> instrumentos;
    instrumentos.push_back(new Guitarra());
    instrumentos.push_back(new Guitarra(7));
    instrumentos.push_back(new Bateria());
    instrumentos.push_back(new Teclado());
    instrumentos.push_back(new Bateria(3));

    for (Instrumento* ins : instrumentos) {
        ins->verlo();
        ins->sonar();
    }

    for (Instrumento* ins : instrumentos) {
        delete ins;
    }

    return 0;
}