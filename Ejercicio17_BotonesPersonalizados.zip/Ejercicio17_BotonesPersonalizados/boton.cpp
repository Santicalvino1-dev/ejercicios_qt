#include "boton.h"
#include "ui_boton.h"
#include <QPainter>
#include <QMouseEvent>

Boton::Boton(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Boton),
    colorFondo(Qt::lightGray)
{
    ui->setupUi(this);
    setAutoFillBackground(false);
}

Boton::~Boton() {
    delete ui;
}

void Boton::colorear(Color color) {
    switch(color) {
        case Azul: colorFondo = QColor("#2196F3"); break;
        case Verde: colorFondo = QColor("#4CAF50"); break;
        case Magenta: colorFondo = QColor("#E91E63"); break;
    }
    update();
}

void Boton::paintEvent(QPaintEvent *) {
    QPainter painter(this);
    painter.fillRect(rect(), colorFondo);
}

void Boton::mousePressEvent(QMouseEvent *event) {
    if (event->button() == Qt::LeftButton) {
        emit signal_clic();
    }
}