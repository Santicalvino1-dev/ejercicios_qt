#include "ventana.h"
#include "ui_ventana.h"
#include "boton.h"
#include <QPainter>

Ventana::Ventana(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Ventana)
{
    ui->setupUi(this);

    // Aplicar colores a los botones promocionados
    ui->boton1->colorear(Boton::Magenta);
    ui->boton2->colorear(Boton::Magenta);
    ui->boton3->colorear(Boton::Magenta);
    ui->boton4->colorear(Boton::Azul);
    ui->boton5->colorear(Boton::Verde);
}

Ventana::~Ventana() {
    delete ui;
}

void Ventana::paintEvent(QPaintEvent *) {
    QPainter painter(this);
    QImage fondo("fondo.png");
    painter.drawImage(rect(), fondo.scaled(size(), Qt::KeepAspectRatioByExpanding, Qt::SmoothTransformation));
}