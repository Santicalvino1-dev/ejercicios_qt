#ifndef BOTON_H
#define BOTON_H

#include <QWidget>

namespace Ui {
class Boton;
}

class Boton : public QWidget {
    Q_OBJECT

public:
    enum Color { Azul, Verde, Magenta };
    explicit Boton(QWidget *parent = nullptr);
    ~Boton();
    void colorear(Color color);

signals:
    void signal_clic();

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;

private:
    Ui::Boton *ui;
    QColor colorFondo;
};

#endif // BOTON_H