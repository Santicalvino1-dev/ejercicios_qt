#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QListWidget>
#include <QDoubleSpinBox>
#include "cajamedicamento.h"

class MainWindow : public QWidget {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

private slots:
    void agregarCaja();
    void compararCajas();
    void sumarCajas();

private:
    QDoubleSpinBox *spinDosis;
    QListWidget *lista;
    void actualizarLista();
};

#endif // MAINWINDOW_H