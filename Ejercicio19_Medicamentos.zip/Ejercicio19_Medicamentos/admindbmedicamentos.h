#ifndef ADMINDBMEDICAMENTOS_H
#define ADMINDBMEDICAMENTOS_H

#include <QSqlDatabase>
#include <QList>
#include "cajamedicamento.h"

class AdminDBMedicamentos {
public:
    static AdminDBMedicamentos& instancia();

    void conectar();
    bool insertarCaja(float dosis);
    QList<CajaMedicamento> obtenerTodas();
    float obtenerTotalDosis();

private:
    AdminDBMedicamentos();
    QSqlDatabase db;
};

#endif // ADMINDBMEDICAMENTOS_H