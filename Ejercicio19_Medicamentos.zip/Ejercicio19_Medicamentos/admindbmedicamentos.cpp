#include "admindbmedicamentos.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QVariant>
#include <QDebug>

AdminDBMedicamentos::AdminDBMedicamentos() {}

AdminDBMedicamentos& AdminDBMedicamentos::instancia() {
    static AdminDBMedicamentos instancia;
    return instancia;
}

void AdminDBMedicamentos::conectar() {
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("cajas.db");
    if (!db.open()) {
        qDebug() << "Error al conectar la base de datos.";
    } else {
        QSqlQuery q;
        q.exec("CREATE TABLE IF NOT EXISTS cajas_medicamentos (id INTEGER PRIMARY KEY AUTOINCREMENT, dosis_totales REAL NOT NULL)");
    }
}

bool AdminDBMedicamentos::insertarCaja(float dosis) {
    if (obtenerTotalDosis() + dosis > 1000)
        return false;

    QSqlQuery q;
    q.prepare("INSERT INTO cajas_medicamentos (dosis_totales) VALUES (?)");
    q.addBindValue(dosis);
    return q.exec();
}

QList<CajaMedicamento> AdminDBMedicamentos::obtenerTodas() {
    QList<CajaMedicamento> lista;
    QSqlQuery q("SELECT id, dosis_totales FROM cajas_medicamentos");
    while (q.next()) {
        lista.append(CajaMedicamento(q.value(0).toInt(), q.value(1).toFloat()));
    }
    return lista;
}

float AdminDBMedicamentos::obtenerTotalDosis() {
    QSqlQuery q("SELECT SUM(dosis_totales) FROM cajas_medicamentos");
    if (q.next())
        return q.value(0).toFloat();
    return 0.0;
}