#include "mainwindow.h"
#include "admindbmedicamentos.h"
#include <QVBoxLayout>
#include <QPushButton>
#include <QMessageBox>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) : QWidget(parent) {
    AdminDBMedicamentos::instancia().conectar();

    QVBoxLayout *layout = new QVBoxLayout(this);

    spinDosis = new QDoubleSpinBox;
    spinDosis->setRange(0.1, 1000);
    layout->addWidget(spinDosis);

    QPushButton *btnAgregar = new QPushButton("Agregar");
    QPushButton *btnComparar = new QPushButton("Comparar");
    QPushButton *btnSumar = new QPushButton("Sumar");
    layout->addWidget(btnAgregar);
    layout->addWidget(btnComparar);
    layout->addWidget(btnSumar);

    lista = new QListWidget;
    layout->addWidget(lista);

    connect(btnAgregar, SIGNAL(clicked()), this, SLOT(agregarCaja()));
    connect(btnComparar, SIGNAL(clicked()), this, SLOT(compararCajas()));
    connect(btnSumar, SIGNAL(clicked()), this, SLOT(sumarCajas()));

    actualizarLista();
}

void MainWindow::actualizarLista() {
    lista->clear();
    auto cajas = AdminDBMedicamentos::instancia().obtenerTodas();
    for (const CajaMedicamento &c : cajas)
        lista->addItem(c.toString());
}

void MainWindow::agregarCaja() {
    float dosis = spinDosis->value();
    if (!AdminDBMedicamentos::instancia().insertarCaja(dosis)) {
        QMessageBox::warning(this, "Límite excedido", "No se puede agregar. Límite de 1000 dosis superado.");
        return;
    }
    actualizarLista();
}

void MainWindow::compararCajas() {
    auto items = lista->selectedItems();
    if (items.size() != 2) return;

    int i1 = lista->row(items[0]);
    int i2 = lista->row(items[1]);
    auto cajas = AdminDBMedicamentos::instancia().obtenerTodas();

    if (cajas[i1] == cajas[i2])
        qDebug() << "Son iguales en dosis.";
    else
        qDebug() << "Son diferentes en dosis.";
}

void MainWindow::sumarCajas() {
    auto items = lista->selectedItems();
    if (items.size() != 2) return;

    int i1 = lista->row(items[0]);
    int i2 = lista->row(items[1]);
    auto cajas = AdminDBMedicamentos::instancia().obtenerTodas();

    CajaMedicamento suma = cajas[i1] + cajas[i2];
    if (!AdminDBMedicamentos::instancia().insertarCaja(suma.getDosis())) {
        QMessageBox::warning(this, "Límite excedido", "No se puede sumar. Límite de 1000 dosis superado.");
        return;
    }
    actualizarLista();
}