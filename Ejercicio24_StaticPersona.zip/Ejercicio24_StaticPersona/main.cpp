#include <QCoreApplication>
#include <QString>
#include <QDebug>

class Persona {
public:
    Persona(QString nombre) : nombre(nombre) {
        ++contador;
    }

    void mostrar() const {
        qDebug() << "Nombre:" << nombre;
    }

    static int totalPersonas() {
        return contador;
    }

private:
    QString nombre;
    static int contador;
};

int Persona::contador = 0;

int main(int argc, char *argv[]) {
    QCoreApplication a(argc, argv);

    Persona p1("Ana");
    Persona p2("Juan");
    Persona p3("Luis");

    p1.mostrar();
    p2.mostrar();
    p3.mostrar();

    qDebug() << "Total de personas creadas:" << Persona::totalPersonas();

    return 0;
}