#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include <QSqlDatabase>

QT_BEGIN_NAMESPACE
namespace Ui { class Login; }
QT_END_NAMESPACE

class Login : public QWidget {
    Q_OBJECT

public:
    Login(QWidget *parent = nullptr);
    ~Login();

private slots:
    void on_botonIngresar_clicked();

private:
    Ui::Login *ui;
    QSqlDatabase db;
    void conectarBase();
    QString md5(const QString &input);
    void cargarUltimoUsuario();
    void guardarUltimoUsuario(const QString &usuario);
};

#endif // LOGIN_H