#include "login.h"
#include "ui_login.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QCryptographicHash>
#include <QFile>
#include <QTextStream>
#include <QDir>

Login::Login(QWidget *parent)
    : QWidget(parent), ui(new Ui::Login)
{
    ui->setupUi(this);
    conectarBase();
    cargarUltimoUsuario();
}

Login::~Login() {
    db.close();
    delete ui;
}

void Login::conectarBase() {
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("usuarios.db");
    if (!db.open()) {
        QMessageBox::critical(this, "Error", "No se pudo conectar a la base de datos.");
    }
}

QString Login::md5(const QString &input) {
    return QString(QCryptographicHash::hash(input.toUtf8(), QCryptographicHash::Md5).toHex());
}

void Login::on_botonIngresar_clicked() {
    QString usuario = ui->usuario->text();
    QString clave = md5(ui->clave->text());

    QSqlQuery query;
    query.prepare("SELECT COUNT(*) FROM usuarios WHERE nombre = ? AND clave = ?");
    query.addBindValue(usuario);
    query.addBindValue(clave);

    if (query.exec() && query.next() && query.value(0).toInt() == 1) {
        guardarUltimoUsuario(usuario);
        QMessageBox::information(this, "Login exitoso", "Bienvenido " + usuario);
        close();
    } else {
        QMessageBox::warning(this, "Login fallido", "Usuario o clave incorrectos.");
        ui->clave->clear();
    }
}

void Login::cargarUltimoUsuario() {
    QFile archivo("ultimo_usuario.txt");
    if (archivo.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&archivo);
        QString usuario = in.readLine();
        ui->usuario->setText(usuario);
        archivo.close();
    }
}

void Login::guardarUltimoUsuario(const QString &usuario) {
    QFile archivo("ultimo_usuario.txt");
    if (archivo.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&archivo);
        out << usuario;
        archivo.close();
    }
}