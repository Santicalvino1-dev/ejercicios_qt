#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

std::string quitarEspacios(const std::string &frase) {
    std::string resultado;
    for (size_t i = 0; i < frase.length(); ++i) {
        if (frase[i] != ' ')
            resultado += frase[i];
    }
    return resultado;
}

bool compararSinEspacios(const std::string &a, const std::string &b) {
    return quitarEspacios(a) < quitarEspacios(b);
}

int main() {
    std::vector<std::string> expresiones;

    expresiones.push_back("pan comido");
    expresiones.push_back("llover sobre mojado");
    expresiones.push_back("matar dos pajaros de un tiro");
    expresiones.push_back("no tener pelos en la lengua");
    expresiones.push_back("costar un ojo de la cara");

    std::cout << "Expresiones originales:" << std::endl;
    for (size_t i = 0; i < expresiones.size(); ++i)
        std::cout << expresiones[i] << std::endl;

    std::sort(expresiones.begin(), expresiones.end(), compararSinEspacios);

    std::cout << "\nExpresiones ordenadas alfabéticamente (ignorando espacios):" << std::endl;
    for (size_t i = 0; i < expresiones.size(); ++i)
        std::cout << expresiones[i] << std::endl;

    return 0;
}