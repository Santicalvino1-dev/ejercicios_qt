#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QFileDialog>
#include <QNetworkAccessManager>
#include <QNetworkReply>

class MainWindow : public QWidget {
    Q_OBJECT
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onDescargarClicked();
    void onRespuesta(QNetworkReply* reply);

private:
    QLineEdit* urlEdit;
    QPushButton* btnDescargar;
    QTextEdit* resultado;
    QNetworkAccessManager* manager;
    QString carpetaDestino;
};

#endif // MAINWINDOW_H