#include "mainwindow.h"
#include <QLabel>
#include <QDebug>
#include <QRegularExpression>
#include <QFile>
#include <QDir>

MainWindow::MainWindow(QWidget *parent)
    : QWidget(parent),
      urlEdit(new QLineEdit(this)),
      btnDescargar(new QPushButton("Descargar", this)),
      resultado(new QTextEdit(this)),
      manager(new QNetworkAccessManager(this)) {

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->addWidget(new QLabel("Ingrese una URL:"));
    layout->addWidget(urlEdit);
    layout->addWidget(btnDescargar);
    layout->addWidget(new QLabel("Recursos encontrados:"));
    layout->addWidget(resultado);

    connect(btnDescargar, SIGNAL(clicked()), this, SLOT(onDescargarClicked()));
    connect(manager, SIGNAL(finished(QNetworkReply*)), this, SLOT(onRespuesta(QNetworkReply*)));
}

MainWindow::~MainWindow() {}

void MainWindow::onDescargarClicked() {
    QString url = urlEdit->text();
    if (!url.startsWith("http")) {
        url = "http://" + url;
    }
    carpetaDestino = QFileDialog::getExistingDirectory(this, "Seleccione carpeta destino");
    if (carpetaDestino.isEmpty()) return;

    manager->get(QNetworkRequest(QUrl(url)));
}

void MainWindow::onRespuesta(QNetworkReply* reply) {
    if (reply->error() != QNetworkReply::NoError) {
        resultado->append("Error al descargar la página.");
        reply->deleteLater();
        return;
    }

    QByteArray html = reply->readAll();
    QString contenido(html);
    resultado->append("HTML descargado...");

    QRegularExpression re("(?:href|src)=["']([^"'>]+)["']");
    QRegularExpressionMatchIterator it = re.globalMatch(contenido);

    while (it.hasNext()) {
        QRegularExpressionMatch match = it.next();
        QString link = match.captured(1);
        if (!link.startsWith("http")) {
            QUrl base = reply->url();
            link = base.resolved(QUrl(link)).toString();
        }

        resultado->append(link);
        QUrl recurso(link);
        QString nombreArchivo = recurso.fileName();
        if (!nombreArchivo.isEmpty()) {
            QNetworkRequest req(recurso);
            QNetworkReply* r = manager->get(req);
            connect(r, &QNetworkReply::finished, this, [r, this, nombreArchivo]() {
                QFile archivo(QDir(carpetaDestino).filePath(nombreArchivo));
                if (archivo.open(QIODevice::WriteOnly)) {
                    archivo.write(r->readAll());
                    archivo.close();
                }
                r->deleteLater();
            });
        }
    }

    reply->deleteLater();
}