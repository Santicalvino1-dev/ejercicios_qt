#include "pintura.h"
#include <QPainter>
#include <QMouseEvent>
#include <QKeyEvent>
#include <QWheelEvent>

Pintura::Pintura(QWidget *parent)
    : QWidget(parent),
      colorPincel(Qt::black),
      tamanioPincel(5),
      dibujando(false)
{
    imagen = QImage(size(), QImage::Format_RGB32);
    imagen.fill(Qt::white);
}

void Pintura::paintEvent(QPaintEvent *) {
    QPainter painter(this);
    painter.drawImage(0, 0, imagen);
}

void Pintura::mousePressEvent(QMouseEvent *event) {
    if (event->button() == Qt::LeftButton) {
        dibujando = true;
        ultimoPunto = event->pos();
    }
}

void Pintura::mouseMoveEvent(QMouseEvent *event) {
    if (dibujando && (event->buttons() & Qt::LeftButton)) {
        QPainter painter(&imagen);
        painter.setPen(QPen(colorPincel, tamanioPincel, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        painter.drawLine(ultimoPunto, event->pos());
        ultimoPunto = event->pos();
        update();
    }
}

void Pintura::keyPressEvent(QKeyEvent *event) {
    switch (event->key()) {
        case Qt::Key_R: colorPincel = Qt::red; break;
        case Qt::Key_G: colorPincel = Qt::green; break;
        case Qt::Key_B: colorPincel = Qt::blue; break;
        case Qt::Key_Escape:
            imagen.fill(Qt::white);
            update();
            break;
    }
}

void Pintura::wheelEvent(QWheelEvent *event) {
    if (event->angleDelta().y() > 0)
        tamanioPincel += 1;
    else if (tamanioPincel > 1)
        tamanioPincel -= 1;
}