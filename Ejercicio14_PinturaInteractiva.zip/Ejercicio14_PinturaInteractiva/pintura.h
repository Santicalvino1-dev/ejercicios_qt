#ifndef PINTURA_H
#define PINTURA_H

#include <QWidget>
#include <QPoint>
#include <QColor>
#include <QImage>

class Pintura : public QWidget {
    Q_OBJECT

public:
    Pintura(QWidget *parent = nullptr);

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void keyPressEvent(QKeyEvent *event) override;
    void wheelEvent(QWheelEvent *event) override;

private:
    QImage imagen;
    QPoint ultimoPunto;
    QColor colorPincel;
    int tamanioPincel;
    bool dibujando;
};

#endif // PINTURA_H