#include "login.h"
#include "ui_login.h"
#include "bienvenida.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDateTime>

Login::Login(QWidget *parent)
    : QWidget(parent), ui(new Ui::Login)
{
    ui->setupUi(this);
    conectarBase();
}

Login::~Login() {
    db.close();
    delete ui;
}

void Login::conectarBase() {
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("usuarios.db");
    if (!db.open()) {
        QMessageBox::critical(this, "Error", "No se pudo conectar a la base de datos.");
    }
}

void Login::on_botonIngresar_clicked() {
    QString usuario = ui->usuario->text();
    QString clave = ui->clave->text();

    QSqlQuery query;
    query.prepare("SELECT ultimo_ingreso FROM usuarios WHERE nombre = ? AND clave = ?");
    query.addBindValue(usuario);
    query.addBindValue(clave);

    if (query.exec() && query.next()) {
        QString ultimoIngreso = query.value(0).toString();

        QSqlQuery update;
        update.prepare("UPDATE usuarios SET ultimo_ingreso = ? WHERE nombre = ?");
        update.addBindValue(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));
        update.addBindValue(usuario);
        update.exec();

        Bienvenida *bienvenida = new Bienvenida(usuario, ultimoIngreso);
        bienvenida->show();
        close();
    } else {
        QMessageBox::warning(this, "Login fallido", "Usuario o clave incorrectos.");
        ui->clave->clear();
    }
}