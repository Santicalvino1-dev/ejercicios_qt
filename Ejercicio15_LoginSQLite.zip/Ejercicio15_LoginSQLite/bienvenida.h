#ifndef BIENVENIDA_H
#define BIENVENIDA_H

#include <QWidget>

class QLabel;

class Bienvenida : public QWidget {
    Q_OBJECT

public:
    Bienvenida(const QString &usuario, const QString &ultimo, QWidget *parent = nullptr);
};

#endif // BIENVENIDA_H