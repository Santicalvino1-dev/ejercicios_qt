#include "bienvenida.h"
#include <QVBoxLayout>
#include <QLabel>

Bienvenida::Bienvenida(const QString &usuario, const QString &ultimo, QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle("Bienvenida");
    QLabel *nombreLabel = new QLabel(usuario);
    nombreLabel->setStyleSheet("font-size: 30px; font-weight: bold");

    QLabel *ingresoLabel = new QLabel("Último ingreso: " + ultimo);
    ingresoLabel->setStyleSheet("font-size: 14px;");

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(nombreLabel);
    layout->addWidget(ingresoLabel);
    setLayout(layout);
}