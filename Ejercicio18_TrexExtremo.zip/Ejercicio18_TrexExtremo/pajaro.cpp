#include "pajaro.h"
#include <QRandomGenerator>

Pajaro::Pajaro(QWidget *parent) : QLabel(parent) {
    setPixmap(QPixmap(":/pajaro.png").scaled(40, 40));
    setFixedSize(40, 40);
    int altura = QRandomGenerator::global()->bounded(100, 200);
    move(800, altura);

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(mover()));
    timer->start(50);
}

void Pajaro::mover() {
    move(x() - 5, y());
    if (x() < -40) deleteLater();
}