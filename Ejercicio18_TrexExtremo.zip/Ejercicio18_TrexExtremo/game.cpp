#include "game.h"
#include <QPainter>
#include <QKeyEvent>
#include <QMessageBox>
#include <QDebug>

Game::Game(QWidget *parent) : QWidget(parent), gameOver(false) {
    setFixedSize(800, 300);
    fondo.load(":/fondo.png");

    trex = new TRex(this);
    trex->move(100, 200);

    timerJuego = new QTimer(this);
    connect(timerJuego, SIGNAL(timeout()), this, SLOT(actualizar()));
    timerJuego->start(30);

    timerPajaro = new QTimer(this);
    connect(timerPajaro, SIGNAL(timeout()), this, SLOT(generarPajaro()));
    timerPajaro->start(5000); // Cada 5 segundos un nuevo pájaro
}

void Game::paintEvent(QPaintEvent *) {
    QPainter painter(this);
    painter.drawImage(rect(), fondo);

    if (gameOver) {
        QImage over(":/gameover.png");
        painter.drawImage(width()/2 - 100, height()/2 - 50, over);
    }
}

void Game::keyPressEvent(QKeyEvent *event) {
    if (gameOver && event->key() == Qt::Key_R) {
        reiniciarJuego();
        return;
    }

    switch (event->key()) {
        case Qt::Key_Space: trex->saltar(); break;
        case Qt::Key_Down: trex->agacharse(); break;
        case Qt::Key_Left: trex->frenar(); break;
        case Qt::Key_Right: trex->adelantar(); break;
    }
}

void Game::actualizar() {
    for (auto p : pajaros) p->mover();
    for (auto c : cactus) c->mover();
    verificarColisiones();
    update();
}

void Game::generarPajaro() {
    Pajaro *p = new Pajaro(this);
    pajaros.append(p);
    p->show();
}

void Game::verificarColisiones() {
    QRect rTrex = trex->geometry();
    for (auto p : pajaros)
        if (rTrex.intersects(p->geometry())) gameOver = true;
    for (auto c : cactus)
        if (rTrex.intersects(c->geometry())) gameOver = true;

    if (gameOver) {
        timerJuego->stop();
        timerPajaro->stop();
        mostrarGameOver();
    }
}

void Game::mostrarGameOver() {
    update();
}

void Game::reiniciarJuego() {
    gameOver = false;
    for (auto p : pajaros) p->deleteLater();
    for (auto c : cactus) c->deleteLater();
    pajaros.clear();
    cactus.clear();
    trex->move(100, 200);
    timerJuego->start(30);
    timerPajaro->start(5000);
}