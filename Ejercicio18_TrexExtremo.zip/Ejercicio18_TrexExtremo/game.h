#ifndef GAME_H
#define GAME_H

#include <QWidget>
#include <QTimer>
#include <QVector>
#include "trex.h"
#include "pajaro.h"
#include "cactus.h"

class Game : public QWidget {
    Q_OBJECT

public:
    explicit Game(QWidget *parent = nullptr);
    void keyPressEvent(QKeyEvent *event) override;

private slots:
    void actualizar();
    void generarPajaro();

private:
    TRex *trex;
    QVector<Pajaro*> pajaros;
    QVector<Cactus*> cactus;
    QTimer *timerJuego;
    QTimer *timerPajaro;
    QImage fondo;
    bool gameOver;

    void verificarColisiones();
    void mostrarGameOver();
    void reiniciarJuego();
};

#endif // GAME_H