#ifndef PAJARO_H
#define PAJARO_H

#include <QLabel>
#include <QTimer>

class Pajaro : public QLabel {
    Q_OBJECT

public:
    explicit Pajaro(QWidget *parent = nullptr);

public slots:
    void mover();

private:
    QTimer *timer;
};

#endif // PAJARO_H