#ifndef CACTUS_H
#define CACTUS_H

#include <QLabel>

class Cactus : public QLabel {
    Q_OBJECT

public:
    explicit Cactus(QWidget *parent = nullptr);
    void mover();
};

#endif // CACTUS_H