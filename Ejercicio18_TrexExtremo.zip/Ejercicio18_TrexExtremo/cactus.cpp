#include "cactus.h"

Cactus::Cactus(QWidget *parent) : QLabel(parent) {
    setPixmap(QPixmap(":/cactus.png").scaled(30, 60));
    setFixedSize(30, 60);
    move(800, 230);
}

void Cactus::mover() {
    move(x() - 4, y());
    if (x() < -30) deleteLater();
}