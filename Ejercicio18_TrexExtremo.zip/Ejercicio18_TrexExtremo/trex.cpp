#include "trex.h"

TRex::TRex(QWidget *parent) : QLabel(parent) {
    setPixmap(QPixmap(":/trex.png").scaled(50, 50));
    setFixedSize(50, 50);
}

void TRex::saltar() {
    move(x(), y() - 30);
}

void TRex::agacharse() {
    move(x(), y() + 30);
}

void TRex::adelantar() {
    move(x() + 10, y());
}

void TRex::frenar() {
    move(x() - 10, y());
}