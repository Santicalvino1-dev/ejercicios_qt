#ifndef TREX_H
#define TREX_H

#include <QLabel>

class TRex : public QLabel {
    Q_OBJECT

public:
    explicit TRex(QWidget *parent = nullptr);
    void saltar();
    void agacharse();
    void adelantar();
    void frenar();
};

#endif // TREX_H