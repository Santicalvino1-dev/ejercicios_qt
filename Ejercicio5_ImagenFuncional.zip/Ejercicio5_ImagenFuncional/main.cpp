#include <QApplication>
#include <QLabel>
#include <QTimer>
#include <QPixmap>
#include <QScreen>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    QLabel *label = new QLabel;

    QPixmap pix(":/imagen.jpg");
    if (pix.isNull()) {
        label->setText("No se pudo cargar la imagen.");
    } else {
        QSize screenSize = QGuiApplication::primaryScreen()->availableSize();
        label->setPixmap(pix.scaled(screenSize, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    }

    label->setWindowTitle("Imagen Alta Resolución");
    label->setAlignment(Qt::AlignCenter);
    label->showMaximized();

    QTimer::singleShot(3000, &app, SLOT(quit()));

    return app.exec();
}