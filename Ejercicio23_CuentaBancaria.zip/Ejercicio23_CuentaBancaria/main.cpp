#include <QCoreApplication>
#include <QDebug>

class CuentaBancaria {
public:
    CuentaBancaria(int saldoInicial) {
        saldo = saldoInicial;
    }

    void depositar(int cantidad) {
        saldo += cantidad;
    }

    void mostrar() const {
        qDebug() << "Saldo actual:" << saldo;
    }

    friend bool compararSaldo(CuentaBancaria c1, CuentaBancaria c2);

private:
    int saldo;
};

bool compararSaldo(CuentaBancaria c1, CuentaBancaria c2) {
    return c1.saldo > c2.saldo;
}

int main(int argc, char *argv[]) {
    QCoreApplication a(argc, argv);

    CuentaBancaria cuenta1(1500);
    CuentaBancaria cuenta2(1200);

    cuenta1.depositar(300);
    cuenta2.depositar(100);

    cuenta1.mostrar();
    cuenta2.mostrar();

    if (compararSaldo(cuenta1, cuenta2)) {
        qDebug() << "Cuenta 1 tiene mayor saldo.";
    } else {
        qDebug() << "Cuenta 2 tiene mayor o igual saldo.";
    }

    return 0;
}